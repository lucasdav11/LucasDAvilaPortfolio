package pokemon;
/**
 * creates a Bulbasaur extending from the Pokemon class implementing grass type
 * It's also one of the starter pokemon a trainer can choose from
 * @author Lucas D'Avila 2017
 *
 */
public class Bulbasaur extends Pokemon implements Grass
{
	/**
	 * Constructor creating a Bulbasaur setting its health as a random number between 40 and 60 and setting its level to either 1 or 2
	 */
	Bulbasaur()
	{
		super("Bulbasaur",Random.Int(40, 60),Random.Int(1, 2));
	}
	@Override
	public int vineWhip() 
	{
		System.out.println(getName() + "uses Vine Whip!");
		return Random.Int(3, 5) * getLevel();
	}
	@Override
	public int razorLeaf() 
	{
		System.out.println(getName() + "uses Razor Leaf!");
		return Random.Int(3, 7) * getLevel();
	}
	@Override
	public int solarBeam() 
	{
		System.out.println(getName() + "uses Solar Beam!");
		return Random.Int(3, 10) * getLevel();
	}
	@Override
	public int getType() 
	{	
		return type;
	}

	@Override
	public void displaySpecialMenu() 
	{
		System.out.println(specialMenu);			
	}
	@Override
	public int specialFight(int m) 
	{
		if (m == 1)
			return vineWhip();
		if (m == 2)
			return razorLeaf();
		if (m == 3)
			return solarBeam();
		
		return 0;
	}
}
