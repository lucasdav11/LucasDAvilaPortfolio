package pokemon;
/**
 * Main that plays Pokemon Game by outputting a series of menus and creating a trainer and several pokemon for the trainer to do battle
 * with until the trainers health goes down to 0 or the user decides to quit the game
 * @author Lucas D'Avila 2017
 *
 */
public class Main {

	public static void main(String[] args) 
	{
		/**
		 * creates the trainer
		 */
		Trainer player = new Trainer("Ash Ketchum", 10);
		int pokeChoice = 0;
		int travelChoice = 0;
		int menuChoice = 0;
		int wildPokeChoice = 0;
		int townChoice = 0;
		int pokeMartChoice = 0;
		/**
		 * creates a starter pokemon based on user input
		 */
		System.out.println("You are a brand new trainer traveling the world in search of battles to win and pokemon to capture!");
		System.out.println("Choose your first pokemon!\n1. Charmander\n2. Squirtle\n3. Bulbasaur");
		pokeChoice = CheckInput.checkIntRange(1,3);
		player.addPokemon(PokemonMaker.makeStartPokemon(pokeChoice));
		System.out.println("You set off on your adventure with your buddy " + player.getCurrentPokemon().getName());
		/**
		 * displays the games main menu until the trainers health becomes 0 or the user decides to quit
		 */
		while((player.getHp() > 0) && menuChoice != 5)
		{
			PokemonBattles.menu();
			menuChoice = CheckInput.checkIntRange(1, 5);
			
			switch(menuChoice)
			{
				case 1:
					travelChoice = Random.Int(1, 7);
					switch(travelChoice)
					{
						/**
						 * a random encounter with a pokemon and displays the battle menu until the wild
						 * pokemons health goes down to 0 or the trainers pokemon health goes down to 0
						 * or the trainer decides to run away
						 * The trainer also has the option to heal their current pokemon or catch the pokemon
						 * they are battling
						 */
						case 1:
							Pokemon wild = PokemonMaker.makeWildPokemon();
							System.out.println("You come across a wild " + wild.getName());
							wild.displayStats();
							player.attackSpeech();
							while ((wild.getHp() > 0) && wildPokeChoice != 1 && (player.getCurrentPokemon().getHp() > 0))
							{
								PokemonBattles.wildPokemonMenu();
								wildPokeChoice = CheckInput.checkIntRange(1, 4);
								switch(wildPokeChoice)
								{
									case 1:
										System.out.println("You ran away!");
										break;
									case 2:
										if(player.getCurrentPokemon().getHp() < 1)
										{
											int damage = Random.Int(1, 3);
											player.loseHp(damage);
											System.out.println(player.getCurrentPokemon().getName() + " is knocked out!");
											System.out.println(wild.getName() + " used Tackle on you! Causing " + damage + " damage!");
										}
										else
										{
											PokemonBattles.pokemonBattle(player, wild);
										}
										break;
									case 3:
										player.healCurrentPokemon();
										break;
									case 4:
										if(player.getNumPokeballs() > 0)
										{
											System.out.println("You throw a Pokeball at " + wild.getName() + ".   Shake...Shake...Shake...");
											System.out.println("You have successfully captured " + wild.getName() + "!");
											player.usePokeball();
											player.addPokemon(wild);
											wildPokeChoice = 1;
										}
										else
											System.out.println("You are out of Pokeballs!");
										break;
									default:
										break;	
								}
							}
							if (wild.getHp() < 1)
							{
								System.out.println(wild.getName() + " fainted!");
								System.out.println(player.getCurrentPokemon().getName() + " gained experience!");
								player.getCurrentPokemon().gainLevel();
								player.winSpeech();
							}
							if (player.getCurrentPokemon().getHp() < 1)
							{
								System.out.println(player.getCurrentPokemon().getName() + " fainted!");
								player.lossSpeech();
							}
							wildPokeChoice = 0;
							break;
						/**
						 * a random encounter with another trainer and displays the battle menu until the
						 * trainers pokemon drops to 0 or the users pokemon drops to 0 or the user decides
						 * to run away
						 * The trainer also has the option to heal their current pokemon but can't catch the other
						 * trainers pokemon	
						 */
						case 2:
							Pokemon trainer = PokemonMaker.makeWildPokemon();
							System.out.println("You come across Trainer Timmy!");
							System.out.println("I'm training to be a Pokemon Master!");
							trainer.displayStats();
							player.attackSpeech();
							while ((trainer.getHp() > 0) && wildPokeChoice != 1 && (player.getCurrentPokemon().getHp() > 0))
							{
								PokemonBattles.wildPokemonMenu();
								wildPokeChoice = CheckInput.checkIntRange(1, 4);
								switch(wildPokeChoice)
								{
									case 1:
										System.out.println("You ran away!");
										break;
									case 2:
										if(player.getCurrentPokemon().getHp() < 1)
										{
											int damage = Random.Int(1, 3);
											player.loseHp(damage);
											System.out.println(player.getCurrentPokemon().getName() + " is knocked out!");
											System.out.println(trainer.getName() + " used Tackle on you! Causing " + damage + " damage!");
										}
										else
										{
											PokemonBattles.pokemonBattle(player, trainer);
										}
										break;
									case 3:
										player.healCurrentPokemon();
										break;
									case 4:
										System.out.println("You can't catch someone else's Pokemon!");
										break;
									default:
										break;	
								}
							}
							if (trainer.getHp() < 1)
							{
								int money = Random.Int(30, 60);
								System.out.println(trainer.getName() + " fainted!");
								System.out.println(player.getCurrentPokemon() + " gained experience!");
								player.getCurrentPokemon().gainLevel();
								System.out.println("Trainer Timmy ran away crying!");
								player.winSpeech();
								System.out.println("You won $" + money);
								player.winAmtMoney(money);
								
							}
							if (player.getCurrentPokemon().getHp() < 1)
							{
								System.out.println(player.getCurrentPokemon().getName() + " fainted!");
								player.lossSpeech();
							}
							wildPokeChoice = 0;
							break;
						/**
						 * a random encounter with team rocket and displays the battle menu until the
						 * team rockets pokemon drops to 0 or the users pokemon drops to 0 or the user decides
						 * to run away
						 * The trainer also has the option to heal their current pokemon but can't catch team rockets
						 * pokemon
						 */
						case 3:
							Pokemon teamRocket = PokemonMaker.makeStartPokemon(Random.Int(1, 3));
							System.out.println("You come across Team Rocket!");
							System.out.println("You come across a Team Rocket\nPrepare for trouble!\nMake it double!\nTo protect the world from devastation!\nTo unite all peoples within our nation!\nTo denounce the evils of truth and love!\nTo extend our reach to the stars above!\nJessie!\nJames!\nTeam Rocket, blast off at the speed of light!\nSurrender now, or prepare to fight!\nMeowth!  That's right!");
							teamRocket.displayStats();
							player.attackSpeech();
							while ((teamRocket.getHp() > 0) && wildPokeChoice != 1 && (player.getCurrentPokemon().getHp() > 0))
							{
								PokemonBattles.wildPokemonMenu();
								wildPokeChoice = CheckInput.checkIntRange(1, 4);
								switch(wildPokeChoice)
								{
									case 1:
										System.out.println("You ran away!");
										break;
									case 2:
										if(player.getCurrentPokemon().getHp() < 1)
										{
											int damage = Random.Int(1, 3);
											player.loseHp(damage);
											System.out.println(player.getCurrentPokemon().getName() + " is knocked out!");
											System.out.println(teamRocket.getName() + " used Tackle on you! Causing " + damage + " damage!");
										}
										else
										{
											PokemonBattles.pokemonBattle(player, teamRocket);
										}
										break;
									case 3:
										player.healCurrentPokemon();
										break;
									case 4:
										System.out.println("You can't catch someone else's Pokemon!");
										break;
									default:
										break;	
								}
							}
							if (teamRocket.getHp() < 1)
							{
								int money = Random.Int(30, 60);
								System.out.println(teamRocket.getName() + " fainted!");
								System.out.println(player.getCurrentPokemon().getName() + " gained experience!");
								player.getCurrentPokemon().gainLevel();
								System.out.println("Team Rocket Blasts off at the Speed of Light!");
								player.winSpeech();
								System.out.println("You won $" + money);
								player.winAmtMoney(money);
								
							}
							if (player.getCurrentPokemon().getHp() < 1)
							{
								System.out.println(player.getCurrentPokemon().getName() + " fainted!");
								player.lossSpeech();
							}
							wildPokeChoice = 0;
							break;
						/**
						 * a random encounter with an angry person
						 */
						case 4:
							PokemonBattles.angryPerson(player);
							break;
						/**
						 * a random encounter with an angry pokemon
						 */
						case 5:
							PokemonBattles.angryPokemon(player);
							break;
						/**
						 * randomly finding a town that allows the trainer to take their pokemon to the pokemon center
						 * and heal all their pokemon and also the trainer can go to the Poke Mart to buy potions and poke
						 * balls
						 */
						case 6:
							while (townChoice != 3)
							{
								System.out.println("You come across a town! What would you like to do here?");
								System.out.println("1. Go to the Pokemon Center\n2. Go to the Poke Mart\n3. Leave");
								townChoice = CheckInput.checkIntRange(1, 3);
								switch (townChoice)
								{
									case 1:
										System.out.println(" Welcome to the Pokemon Center!");
										System.out.println("--------------------------------");
										System.out.println("\nNurse Joy healed all your Pokemon!");
										player.healAllPokemon();
										break;
									case 2:
										while (pokeMartChoice != 3)
										{
											System.out.println(" Welcome to the Poke Mart!");
											System.out.println("---------------------------");
											System.out.println("\nWhat would you like to do here?");
											System.out.println("1. Buy a Pokeball ($10)\n2. Buy a Potion ($5)\n3. Leave");
											pokeMartChoice = CheckInput.checkIntRange(1, 3);
											switch (pokeMartChoice)
											{
												case 1:
													if(player.getAmtMoney() > 10)
													{
														player.gainPokeball();
														player.spendMoney(10);
														System.out.println("You purchased a Poke Ball!");
													}
													else
														System.out.println("You don't have enough Money!");
													break;
												case 2:
													if(player.getAmtMoney() > 5)
													{
														player.gainPotion();
														player.spendMoney(5);
														System.out.println("You purchased a Potion!");
													}
													else
														System.out.println("You don't have enough Money!");
													break;
												case 3:
													System.out.println("You are leaving the Poke Mart!");
													break;
											}
										
										}
										pokeMartChoice = 0;
										break;
									case 3:
										System.out.println("You are leaving Town!");
										break;
								}
	
							}
							townChoice = 0;
							break;
						case 7:
							System.out.println("You travel around the route and find nothing...");
							break;
					}
					break;
				/**
				 * Allows the user to change his current pokemon to use for battle
				 */
				case 2:
					System.out.println("Pokemon:");
					player.displayAllPokemon();
					System.out.println("Which Pokemon do you want to use for battle?");
					player.setCurrentPokemon(CheckInput.checkIntRange(1, player.numberofPokemon()));
					break;
				/**
				 * heals the trainers current pokemon
				 */
				case 3:
					player.healCurrentPokemon();
					player.getCurrentPokemon().displayStats();
					break;
				/**
				 * displays the trainers stats
				 */
				case 4:
					player.displayStats();
					break;
				/**
				 * quits the game
				 */
				case 5:
					System.out.println("Game not saved! Goodbye!");
					break;
				default:
					System.out.println("INVALID");
					break;
			}
		}
		/**
		 * displays a message if the trainers health falls below 0
		 */
		if (player.getHp() < 0)
			System.out.println("The adventure was to much for you and you lost all your health! Game Over!");
	}

}
