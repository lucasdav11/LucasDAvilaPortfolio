package pokemon;
/**
 * Static methods used to find a random numbers between a min and a max range
 * @author Lucas D'Avila 2017
 *
 */
public class Random 
{
	/**
	 * Uses the math random function to find a random int between a min and a max range
	 * @param min range
	 * @param max range
	 * @return random int between min and max
	 */
	public static int Int(int min, int max)
	{
		return (int)(Math.random() * max + min);
	}
}
