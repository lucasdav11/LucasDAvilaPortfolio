package pokemon;
/**
 * Creates a Staryu extending from the Pokemon class implementing water type
 * It is also one of the random pokemon that the trainer can encounter on their journey
 * @author Lucas D'Avila 2017
 *
 */
public class Staryu extends Pokemon implements Water
{
	/**
	 * Constructor creating a Staryu setting its health as a random number between 15 and 30 and setting its level to either 1 or 2
	 */
	Staryu()
	{
		super("Staryu",Random.Int(15, 30),Random.Int(1, 2));
	}

	@Override
	public int waterGun() 
	{
		System.out.println(getName() + "uses Water Gun!");
		return Random.Int(3, 5) * getLevel();
	}

	@Override
	public int bubbleBeam() 
	{
		System.out.println(getName() + "uses Bubble Beam!");
		return Random.Int(3, 7) * getLevel();
	}

	@Override
	public int hydroPump() 
	{
		System.out.println(getName() + "uses Hydro Pump!");
		return Random.Int(3, 10) * getLevel();
	}

	@Override
	public int getType() 
	{	
		return type;
	}

	@Override
	public void displaySpecialMenu() 
	{
		System.out.println(specialMenu);			
	}

	@Override
	public int specialFight(int m) 
	{
		if (m == 1)
			return waterGun();
		if (m == 2)
			return bubbleBeam();
		if (m == 3)
			return hydroPump();
		
		return 0;
	}
}
