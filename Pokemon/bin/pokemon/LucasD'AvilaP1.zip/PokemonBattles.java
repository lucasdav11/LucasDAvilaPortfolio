package pokemon;
/**
 * Static methods that has the trainer battling random pokemon, other trainers and encountering angry pokemon and trainers
 * It also has static methods that output the main game menu along with the battle menu
 * @author Lucas
 *
 */
public class PokemonBattles 
{
	/**
	 * double array that stores the pokemons damage ration based on types for pokemon battle damage calculations
	 */
	private final static double [][] fightTable = {{1,.5,2}, {2,1,.5}, {.5,2,1}};
	/**
	 * Static method that has the trainers pokemon battle another pokemon displaying each pokemons stats along with
	 * calculating the damage they deal based on what type they are
	 * @param trainer pokemon
	 * @param pokemon trainer battles
	 */
	public static void pokemonBattle(Trainer player, Pokemon poke)
	{
			double playerDamage, pokeDamage;
			
			playerDamage = player.battle() * fightTable[player.getCurrentPokemon().getType()][poke.getType()];
			pokeDamage = poke.basicFight(Random.Int(1, 3)) * fightTable[poke.getType()][player.getCurrentPokemon().getType()];
			
			player.getCurrentPokemon().loseHp((int) pokeDamage);
			poke.loseHp((int)playerDamage); 
			
			
			player.getCurrentPokemon().displayStats();
			poke.displayStats();
	}
	/**
	 * static method that has the trainer randomly encounter an angry pokemon that deals damage to the trainer himself
	 * @param trainer
	 */
	public static void angryPokemon(Trainer player)
	{
		int choice = Random.Int(1, 3);
		int damage = 0;
		
		switch(choice)
		{
		case 1:
			damage = Random.Int(1, 3);
			player.loseHp(damage);
			System.out.println("You've come across a sick Pikachu!");
			System.out.println("You tried to help it\n Pikachu accientally shocked you! Causing " + damage + " damage!");
			break;
		case 2:
			damage = Random.Int(1, 3);
			player.loseHp(damage);
			System.out.println("You've come across a flock of wild Spearow!");
			System.out.println("They all flew in and pecked at you! Causing " + damage + " damage!" );
			break;
		case 3:
			damage = Random.Int(1, 3);
			player.loseHp(damage);
			System.out.println("You've come across MewTwo!");
			System.out.println("You tried throwing a pokeBall\nMewTwo sent it back flying at your head! Causing " + damage + " damage!");
			break;
		default:
			break;
		}
		
	}
	/**
	 * static method that has the trainer randomly encounter an angry person that deals damage to the trainer himslef
	 * @param trainer
	 */
	public static void angryPerson(Trainer player)
	{
		int choice = Random.Int(1, 3);
		int damage = 0;
		
		switch(choice)
		{
		case 1:
			damage = Random.Int(1, 3);
			player.loseHp(damage);
			System.out.println("You run across Misty");
			System.out.println("Where's my bike twerp!?\nMisty whacks you in the head! Causing " + damage + " damage!");
			break;
		case 2:
			damage = Random.Int(1, 3);
			player.loseHp(damage);
			System.out.println("You run across Team Rocket");
			System.out.println("You come across a Team Rocket\nPrepare for trouble!\nMake it double!\nTo protect the world from devastation!\nTo unite all peoples within our nation!\nTo denounce the evils of truth and love!\nTo extend our reach to the stars above!\nJessie!\nJames!\nTeam Rocket, blast off at the speed of light!\nSurrender now, or prepare to fight!\nMeowth!  That's right! \nMeowth scratches you! Causing " + damage + " damage!" );
			break;
		case 3:
			damage = Random.Int(1, 3);
			player.loseHp(damage);
			System.out.println("You run across Brock");
			System.out.println(" He says Nurse Joy!\nBrock tramples over you! Causing " + damage + " damage!");
			break;
		default:
			break;
		}
		
	}
	/**
	 * static method that displays the games main menu
	 */
	public static void menu()
	{
		System.out.println("What would you like to do?");
		System.out.println("1. Travel\n2. Switch Pokemon\n3. Heal Current Pokemon\n4. View Stats\n5. Quit Game");
	}
	/**
	 * static method that displays the menu when the trainer encounters a battle
	 */
	public static void wildPokemonMenu()
	{
		System.out.println("What would you like to do?");
		System.out.println("1. Run Away\n2. Fight\n3. Use Potion\n4. Throw Pokeball");
	}
}
