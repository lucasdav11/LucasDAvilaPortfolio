package pokemon;
/**
 * Creates an Oddish extending from the Pokemon class implementing grass type
 * It's also one of the random pokemon that can appear on the trainers journey
 * @author Lucas D'Avila 2017
 *
 */
public class Oddish extends Pokemon implements Grass
{
	/**
	 * Constructor creating a Oddish setting its health as a random number between 15 and 30 and setting its level to either 1 or 2
	 */
	Oddish()
	{
		super("Oddish",Random.Int(15, 30),Random.Int(1, 2));
	}

	@Override
	public int vineWhip() 
	{
		System.out.println(getName() + "uses Vine Whip!");
		return Random.Int(3, 5) * getLevel();
	}

	@Override
	public int razorLeaf() 
	{
		System.out.println(getName() + "uses Razor Leaf!");
		return Random.Int(3, 7) * getLevel();
	}

	@Override
	public int solarBeam() 
	{
		System.out.println(getName() + "uses Solar Beam!");
		return Random.Int(3, 10) * getLevel();
	}

	@Override
	public int getType() 
	{	
		return type;
	}

	@Override
	public void displaySpecialMenu() 
	{
		System.out.println(specialMenu);			
	}

	@Override
	public int specialFight(int m) 
	{
		if (m == 1)
			return vineWhip();
		if (m == 2)
			return razorLeaf();
		if (m == 3)
			return solarBeam();
		
		return 0;
	}
}
